# Copyright (C) 2007 AG Projects. See LICENSE for details.
#
