# Copyright (C) 2008 AG-Projects.
#

"""Interfaces to various accounting backends"""

