# Copyright (C) 2006-2009 Dan Pascu. See LICENSE for details.
#

"""Basic building blocks for python applications"""

__version__ = "1.3.0"

