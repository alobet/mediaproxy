# Copyright (C) 2009 Dan Pascu. See LICENSE for details.
#

